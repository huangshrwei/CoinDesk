import { NgbTransitionStartFn } from '../util/transition/ngbTransition';
export declare const ngbAlertFadingTransition: NgbTransitionStartFn;

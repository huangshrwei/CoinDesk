import * as i0 from "@angular/core";
import * as i1 from "./collapse";
export { NgbCollapse } from './collapse';
export { NgbCollapseConfig } from './collapse-config';
export declare class NgbCollapseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgbCollapseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgbCollapseModule, never, [typeof i1.NgbCollapse], [typeof i1.NgbCollapse]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgbCollapseModule>;
}

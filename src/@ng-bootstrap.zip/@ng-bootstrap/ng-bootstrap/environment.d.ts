export declare const environment: {
    animation: boolean;
    transitionTimerDelayMs: number;
};

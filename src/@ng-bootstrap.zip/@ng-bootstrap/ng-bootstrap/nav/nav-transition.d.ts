import { NgbTransitionStartFn } from '../util/transition/ngbTransition';
export declare const ngbNavFadeOutTransition: NgbTransitionStartFn;
export declare const ngbNavFadeInTransition: NgbTransitionStartFn;

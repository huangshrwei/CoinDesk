import * as i0 from "@angular/core";
/**
 * Global ng-bootstrap config
 *
 * @since 8.0.0
 */
export declare class NgbConfig {
    animation: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgbConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgbConfig>;
}

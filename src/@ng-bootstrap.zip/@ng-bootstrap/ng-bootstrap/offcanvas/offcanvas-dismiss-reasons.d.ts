export declare enum OffcanvasDismissReasons {
    BACKDROP_CLICK = 0,
    ESC = 1
}

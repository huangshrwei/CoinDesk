import { NgbScrollSpyProcessChanges } from './scrollspy.service';
export declare function toFragmentElement(container: Element | null, id?: string | HTMLElement | null): HTMLElement | null;
export declare const defaultProcessChanges: NgbScrollSpyProcessChanges;

import { NgbTransitionStartFn } from '../util/transition/ngbTransition';
export declare const ngbToastFadeInTransition: NgbTransitionStartFn;
export declare const ngbToastFadeOutTransition: NgbTransitionStartFn;

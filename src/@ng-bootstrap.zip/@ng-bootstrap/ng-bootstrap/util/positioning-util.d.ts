import { Options } from '@popperjs/core';
export declare function addPopperOffset(offset: number[]): (options: Partial<Options>) => Partial<Options>;

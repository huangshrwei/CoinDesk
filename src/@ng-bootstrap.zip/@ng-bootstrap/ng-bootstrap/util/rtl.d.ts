import * as i0 from "@angular/core";
export declare class NgbRTL {
    private _element;
    isRTL(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgbRTL, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgbRTL>;
}

export declare function getTransitionDurationMs(element: HTMLElement): number;

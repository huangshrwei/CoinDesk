Angular
=======

The sources for this package are in the main [Angular](https://github.com/angular/angular) repo. Please file issues and pull requests against that repo.

Usage information and reference details can be found in [Angular documentation](https://angular.io/docs).

License: MIT
